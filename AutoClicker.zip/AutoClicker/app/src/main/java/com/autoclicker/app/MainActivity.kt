package com.autoclicker.app

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.text.InputType
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val prefs = getSharedPreferences("cfg", Context.MODE_PRIVATE)
        val pad = (20 * resources.displayMetrics.density).toInt()

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad * 2, pad, pad)
        }

        val info = TextView(this).apply {
            textSize = 16f
            text = "1. Включи службу AutoClicker в «Специальных возможностях».\n" +
                    "2. Появится панель и красная точка-цель.\n" +
                    "3. Перетащи точку туда, куда нужно кликать.\n" +
                    "4. Жми ▶ на панели — старт, ⏸ — стоп. ☰ — перетащить панель, ✕ — убрать."
        }

        val input = EditText(this).apply {
            inputType = InputType.TYPE_CLASS_NUMBER
            hint = "Интервал между кликами, мс (минимум 50)"
            setText(prefs.getLong("interval", 100L).toString())
        }

        val save = Button(this).apply {
            text = "Сохранить интервал"
            setOnClickListener {
                val v = input.text.toString().toLongOrNull()?.coerceAtLeast(50L) ?: 100L
                prefs.edit().putLong("interval", v).apply()
                input.setText(v.toString())
                Toast.makeText(this@MainActivity, "Интервал: $v мс", Toast.LENGTH_SHORT).show()
            }
        }

        val access = Button(this).apply {
            text = "Открыть настройки спец. возможностей"
            setOnClickListener {
                startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            }
        }

        val toggle = Button(this).apply {
            text = "Показать / скрыть панель"
            setOnClickListener {
                val s = ClickService.instance
                if (s == null) {
                    Toast.makeText(this@MainActivity, "Сначала включи службу", Toast.LENGTH_SHORT).show()
                } else {
                    s.toggleOverlay()
                }
            }
        }

        root.addView(info)
        root.addView(input)
        root.addView(save)
        root.addView(access)
        root.addView(toggle)
        setContentView(root)
    }
}
