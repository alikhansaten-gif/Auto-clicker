package com.autoclicker.app

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Context
import android.graphics.Color
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.widget.LinearLayout
import android.widget.TextView

class ClickService : AccessibilityService() {

    companion object {
        @Volatile
        var instance: ClickService? = null
    }

    private lateinit var wm: WindowManager
    private val handler = Handler(Looper.getMainLooper())

    private var panel: View? = null
    private var target: View? = null
    private var panelLp: WindowManager.LayoutParams? = null
    private var targetLp: WindowManager.LayoutParams? = null
    private var playBtn: TextView? = null
    private var running = false

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
        wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        showOverlay()
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}

    override fun onInterrupt() {}

    override fun onUnbind(intent: android.content.Intent?): Boolean {
        hideOverlay()
        instance = null
        return super.onUnbind(intent)
    }

    override fun onDestroy() {
        hideOverlay()
        instance = null
        super.onDestroy()
    }

    fun toggleOverlay() {
        if (panel == null) showOverlay() else hideOverlay()
    }

    private fun newLp(w: Int, h: Int, x: Int, y: Int) = WindowManager.LayoutParams(
        w, h,
        WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
        WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
        PixelFormat.TRANSLUCENT
    ).apply {
        gravity = Gravity.TOP or Gravity.START
        this.x = x
        this.y = y
    }

    private fun showOverlay() {
        if (panel != null) return
        val dm = resources.displayMetrics

        // --- Цель (перекрестие) ---
        val size = dp(56)
        val t = TextView(this).apply {
            text = "+"
            gravity = Gravity.CENTER
            setTextColor(Color.WHITE)
            textSize = 28f
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(Color.argb(110, 255, 59, 48))
                setStroke(dp(2), Color.WHITE)
            }
        }
        val tLp = newLp(size, size, dm.widthPixels / 2 - size / 2, dm.heightPixels / 2 - size / 2)
        makeDraggable(t, t, tLp)
        wm.addView(t, tLp)
        target = t
        targetLp = tLp

        // --- Панель управления ---
        fun btn(label: String) = TextView(this).apply {
            text = label
            textSize = 22f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            setPadding(dp(14), dp(8), dp(14), dp(8))
        }

        val handle = btn("☰")
        val play = btn("▶")
        val close = btn("✕")
        playBtn = play

        val p = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            background = GradientDrawable().apply {
                cornerRadius = dp(28).toFloat()
                setColor(Color.argb(230, 30, 30, 30))
            }
            addView(handle)
            addView(play)
            addView(close)
        }
        val pLp = newLp(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            dp(16), dp(120)
        )
        makeDraggable(handle, p, pLp)
        play.setOnClickListener { if (running) stopClicking() else startClicking() }
        close.setOnClickListener { hideOverlay() }
        wm.addView(p, pLp)
        panel = p
        panelLp = pLp
    }

    private fun hideOverlay() {
        stopClicking()
        try { panel?.let { wm.removeView(it) } } catch (_: Exception) {}
        try { target?.let { wm.removeView(it) } } catch (_: Exception) {}
        panel = null
        target = null
        panelLp = null
        targetLp = null
        playBtn = null
    }

    private fun makeDraggable(handle: View, view: View, lp: WindowManager.LayoutParams) {
        var sx = 0f
        var sy = 0f
        var ox = 0
        var oy = 0
        handle.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> {
                    sx = e.rawX; sy = e.rawY; ox = lp.x; oy = lp.y
                }
                MotionEvent.ACTION_MOVE -> {
                    lp.x = ox + (e.rawX - sx).toInt()
                    lp.y = oy + (e.rawY - sy).toInt()
                    try { wm.updateViewLayout(view, lp) } catch (_: Exception) {}
                }
            }
            true
        }
    }

    private fun startClicking() {
        if (running) return
        running = true
        playBtn?.text = "⏸"
        // Во время клика цель не должна перехватывать нажатия
        targetLp?.let {
            it.flags = it.flags or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
            try { wm.updateViewLayout(target, it) } catch (_: Exception) {}
        }
        handler.post(clickRunnable)
    }

    private fun stopClicking() {
        running = false
        handler.removeCallbacks(clickRunnable)
        playBtn?.text = "▶"
        targetLp?.let {
            it.flags = it.flags and WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE.inv()
            try { target?.let { v -> wm.updateViewLayout(v, it) } } catch (_: Exception) {}
        }
    }

    private val clickRunnable = object : Runnable {
        override fun run() {
            if (!running) return
            val t = target ?: return
            val loc = IntArray(2)
            t.getLocationOnScreen(loc)
            val x = loc[0] + t.width / 2f
            val y = loc[1] + t.height / 2f

            val path = Path().apply { moveTo(x, y) }
            val gesture = GestureDescription.Builder()
                .addStroke(GestureDescription.StrokeDescription(path, 0, 30))
                .build()
            dispatchGesture(gesture, null, null)

            val interval = getSharedPreferences("cfg", Context.MODE_PRIVATE)
                .getLong("interval", 100L).coerceAtLeast(50L)
            handler.postDelayed(this, interval)
        }
    }
}
